#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/module.h>
#include <linux/semaphore.h>
#include <linux/time.h>
#include <linux/unistd.h>

static struct task_struct *task1;
static struct task_struct *task2;

int count = 20;
module_param(maxcount, int, S_IRUGO);

static DEFINE_SEMAPHORES(s1)
static DEFINE_SEMAPHORES(s2)

static int thread_one(void *pargs)
{
	int i = 0;
	printk("thread A welcome\n");
	down_interruptible(&s1);
	down_interruptible(&s2);
	
	for(i=1; i <= count; i++)
	{
		printk("Thread A Thank you\n");
		msleep(500);
	}
	printk("stopping thread A\n");
	up(&s1);
	return 0;
}

static int thread_two(void *pargs) 
{
	int i = 0; 
	printk("thread B welcome\n");
	down_interruptible(&s2);
	for(i=1; i<=count; i++)
	{
		printk("Thread B Thank you\n");
		msleep(500);
		//val--
		//if(kthread_should_stop())
		//break;
	}
	up(&s1);
	up(&s2);
	do_exit(0);
	return 0;
}

static int __init sema_init(void)
{
	sema_init(&s2, 0);
	task1 = kthread_run(thread_one, NULL, "thread_A);
	task2 = kthread_run(thread_two, NULL, "thread_B");
	printk("semaphores sample--welcome\n");
	return 0;
}
static void __exit sema_exit(void)
{
	printk("Semaphores Bye");
	
}

module_init(sema_init);
module_exit(sema_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("NEHA");
MODULE_DESCRIPTION("Sema module")
