#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/kfifo.h>

unsigned char *pbuffer;

#define MAX_SIZE 1024

struct kfifo myfifo;
struct cdev cdev;
struct device *pdev;
struct class *pclass;


int ndevices=1;
struct file_operations fops = {
    .open = pseudo_open,
    .release = pseudo_close,
    .write = pseudo_write,
    .read = pseudo_read
};


int i=0;
dev_t pdevid;
unsigned char *pbuffer;
int rd_offset=0;
int wr_offset=0;
int buflen=0;
int ret=0;
int tbuf;

int pseudo_open(struct inode *inode , struct file *file)
{
    printk("Pseudo---open_method\n");
    return 0;
}
int pseudo_close(struct inode *inode , struct file *file)
{
    printk("Pseudo---release_method\n");
    return 0;
}
ssize_t pseudo_read(struct file *file, char __user *buf , size_t size, loff_t *off)
{
	int rcount;
    printk("Pseudo---release_method\n");
    if(kfifo_is_empty(&myfifo))
    {
    	printk("Buffer is empty\n");
    	return 0;
    }
    rcount = size; 
    if(rcount > kfifo_len(&myfifo))
    	rcount = kfifo_len(&myfifo);
    	
    tbuf = kmalloc(rcount, GFP_KERNEL);
    kfifo_out(&myfifo, tbuf, rcount);
    
    ret = copy_to_user(buf, tbuf, rcount);
    
    //kfree(tbuf);
    
}

ssize_t pseudo_write(struct file * file, const char __user * buf , size_t size, loff_t * off)
{
    printk("Pseudo---write_method\n");
    if (kfifo_is_full(&myfifo))
    {
    	printk("buffer is full\n");
    	return -ENOSPC;
    }
    int wcount = size;
    if (wcount > kfifo_avail(&myfifo))
    	wcount = kfifo_avail(&myfifo);      //min
    	
    char *tbuf=kmalloc(wcount, GFP_KERNEL);
    
    ret=copy_from_user(tbuf, buf, wcount);
    
    kfifo_in(&myfifo, tbuf, wcount);
    //kfree(tbuf);
    return 0;
}

static int __init psuedo_init(void)
{	
    int ret;
    int i=0;
    pclass = class_create(THIS_MODULE, "pseudo_class");
    ret=alloc_chrdev_region(&pdevid, 0, ndevices, "pseudo_sample");
    if (ret) {
    printk("Pseudo: Failed to register driver\n");
    return -EINVAL;
  }
    pdev = device_create(pclass, NULL, pdevid, NULL, "psample%d", i);
    
    
    
    
    pbuffer = kmalloc(MAX_SIZE, GFP_KERNEL);
    kfifo_init(&myfifo,pbuffer, MAX_SIZE);

    cdev_init(&cdev, &fops);
    kobject_set_name(&cdev.kobj,"pdevice%d",i);
    ret = cdev_add(&cdev, pdevid, 1);
    
    printk("Successfully registered,major=%d, minor=%d\n",MAJOR(pdevid), MINOR(pdevid));
    printk("Pseudo Driver Sample..welcome\n");
    
    printk("count is %d",rd_offset);
    
    return 0;
}
static void __exit psuedo_exit(void) 
{
    
    unregister_chrdev_region(pdevid, ndevices);
    printk("Pseudo Driver Sample..Bye\n");
    cdev_del(&cdev);
    device_destroy(pclass, pdevid);
    class_destroy(pclass);
    kfree(pbuffer);
    
    
    
    //kfifo_free(kfifo);
}

module_init(psuedo_init);
module_exit(psuedo_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your name");
MODULE_DESCRIPTION("Parameter demo Module");
