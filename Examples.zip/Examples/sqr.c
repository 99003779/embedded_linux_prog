//sqr.c
int square(int x)
{
return x * x;
}
